﻿namespace Project
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.park2 = new System.Windows.Forms.Button();
            this.park3 = new System.Windows.Forms.Button();
            this.park4 = new System.Windows.Forms.Button();
            this.park5 = new System.Windows.Forms.Button();
            this.park6 = new System.Windows.Forms.Button();
            this.park7 = new System.Windows.Forms.Button();
            this.park8 = new System.Windows.Forms.Button();
            this.park9 = new System.Windows.Forms.Button();
            this.park10 = new System.Windows.Forms.Button();
            this.park11 = new System.Windows.Forms.Button();
            this.park12 = new System.Windows.Forms.Button();
            this.park13 = new System.Windows.Forms.Button();
            this.park14 = new System.Windows.Forms.Button();
            this.park15 = new System.Windows.Forms.Button();
            this.park16 = new System.Windows.Forms.Button();
            this.park17 = new System.Windows.Forms.Button();
            this.park18 = new System.Windows.Forms.Button();
            this.park19 = new System.Windows.Forms.Button();
            this.park20 = new System.Windows.Forms.Button();
            this.park21 = new System.Windows.Forms.Button();
            this.park22 = new System.Windows.Forms.Button();
            this.park23 = new System.Windows.Forms.Button();
            this.park24 = new System.Windows.Forms.Button();
            this.park25 = new System.Windows.Forms.Button();
            this.park26 = new System.Windows.Forms.Button();
            this.park27 = new System.Windows.Forms.Button();
            this.park28 = new System.Windows.Forms.Button();
            this.park29 = new System.Windows.Forms.Button();
            this.park30 = new System.Windows.Forms.Button();
            this.park1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(42, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "주차 공간 배치도";
            // 
            // park2
            // 
            this.park2.FlatAppearance.BorderSize = 0;
            this.park2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park2.ForeColor = System.Drawing.Color.White;
            this.park2.Location = new System.Drawing.Point(214, 124);
            this.park2.Name = "park2";
            this.park2.Size = new System.Drawing.Size(47, 77);
            this.park2.TabIndex = 5;
            this.park2.Text = "02";
            this.park2.UseVisualStyleBackColor = true;
            this.park2.Click += new System.EventHandler(this.park2_Click);
            // 
            // park3
            // 
            this.park3.FlatAppearance.BorderSize = 0;
            this.park3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park3.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park3.ForeColor = System.Drawing.Color.White;
            this.park3.Location = new System.Drawing.Point(266, 124);
            this.park3.Name = "park3";
            this.park3.Size = new System.Drawing.Size(47, 77);
            this.park3.TabIndex = 6;
            this.park3.Text = "03";
            this.park3.UseVisualStyleBackColor = true;
            this.park3.Click += new System.EventHandler(this.park3_Click);
            // 
            // park4
            // 
            this.park4.FlatAppearance.BorderSize = 0;
            this.park4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park4.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park4.ForeColor = System.Drawing.Color.White;
            this.park4.Location = new System.Drawing.Point(318, 124);
            this.park4.Name = "park4";
            this.park4.Size = new System.Drawing.Size(47, 77);
            this.park4.TabIndex = 7;
            this.park4.Text = "04";
            this.park4.UseVisualStyleBackColor = true;
            this.park4.Click += new System.EventHandler(this.park4_Click);
            // 
            // park5
            // 
            this.park5.FlatAppearance.BorderSize = 0;
            this.park5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park5.ForeColor = System.Drawing.Color.White;
            this.park5.Location = new System.Drawing.Point(370, 124);
            this.park5.Name = "park5";
            this.park5.Size = new System.Drawing.Size(47, 77);
            this.park5.TabIndex = 8;
            this.park5.Text = "05";
            this.park5.UseVisualStyleBackColor = true;
            this.park5.Click += new System.EventHandler(this.park5_Click);
            // 
            // park6
            // 
            this.park6.FlatAppearance.BorderSize = 0;
            this.park6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park6.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park6.ForeColor = System.Drawing.Color.White;
            this.park6.Location = new System.Drawing.Point(422, 124);
            this.park6.Name = "park6";
            this.park6.Size = new System.Drawing.Size(47, 77);
            this.park6.TabIndex = 9;
            this.park6.Text = "06";
            this.park6.UseVisualStyleBackColor = true;
            this.park6.Click += new System.EventHandler(this.park6_Click);
            // 
            // park7
            // 
            this.park7.FlatAppearance.BorderSize = 0;
            this.park7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park7.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park7.ForeColor = System.Drawing.Color.White;
            this.park7.Location = new System.Drawing.Point(474, 124);
            this.park7.Name = "park7";
            this.park7.Size = new System.Drawing.Size(47, 77);
            this.park7.TabIndex = 10;
            this.park7.Text = "07";
            this.park7.UseVisualStyleBackColor = true;
            this.park7.Click += new System.EventHandler(this.park7_Click);
            // 
            // park8
            // 
            this.park8.FlatAppearance.BorderSize = 0;
            this.park8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park8.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park8.ForeColor = System.Drawing.Color.White;
            this.park8.Location = new System.Drawing.Point(526, 124);
            this.park8.Name = "park8";
            this.park8.Size = new System.Drawing.Size(47, 77);
            this.park8.TabIndex = 11;
            this.park8.Text = "08";
            this.park8.UseVisualStyleBackColor = true;
            this.park8.Click += new System.EventHandler(this.park8_Click);
            // 
            // park9
            // 
            this.park9.FlatAppearance.BorderSize = 0;
            this.park9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park9.ForeColor = System.Drawing.Color.White;
            this.park9.Location = new System.Drawing.Point(578, 124);
            this.park9.Name = "park9";
            this.park9.Size = new System.Drawing.Size(47, 77);
            this.park9.TabIndex = 12;
            this.park9.Text = "09";
            this.park9.UseVisualStyleBackColor = true;
            this.park9.Click += new System.EventHandler(this.park9_Click);
            // 
            // park10
            // 
            this.park10.FlatAppearance.BorderSize = 0;
            this.park10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park10.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park10.ForeColor = System.Drawing.Color.White;
            this.park10.Location = new System.Drawing.Point(630, 124);
            this.park10.Name = "park10";
            this.park10.Size = new System.Drawing.Size(47, 77);
            this.park10.TabIndex = 13;
            this.park10.Text = "10";
            this.park10.UseVisualStyleBackColor = true;
            this.park10.Click += new System.EventHandler(this.park10_Click);
            // 
            // park11
            // 
            this.park11.FlatAppearance.BorderSize = 0;
            this.park11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park11.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park11.ForeColor = System.Drawing.Color.White;
            this.park11.Location = new System.Drawing.Point(162, 287);
            this.park11.Name = "park11";
            this.park11.Size = new System.Drawing.Size(47, 77);
            this.park11.TabIndex = 14;
            this.park11.Text = "11";
            this.park11.UseVisualStyleBackColor = true;
            this.park11.Click += new System.EventHandler(this.park11_Click);
            // 
            // park12
            // 
            this.park12.FlatAppearance.BorderSize = 0;
            this.park12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park12.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park12.ForeColor = System.Drawing.Color.White;
            this.park12.Location = new System.Drawing.Point(214, 287);
            this.park12.Name = "park12";
            this.park12.Size = new System.Drawing.Size(47, 77);
            this.park12.TabIndex = 15;
            this.park12.Text = "12";
            this.park12.UseVisualStyleBackColor = true;
            this.park12.Click += new System.EventHandler(this.park12_Click);
            // 
            // park13
            // 
            this.park13.FlatAppearance.BorderSize = 0;
            this.park13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park13.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park13.ForeColor = System.Drawing.Color.White;
            this.park13.Location = new System.Drawing.Point(266, 287);
            this.park13.Name = "park13";
            this.park13.Size = new System.Drawing.Size(47, 77);
            this.park13.TabIndex = 16;
            this.park13.Text = "13";
            this.park13.UseVisualStyleBackColor = true;
            this.park13.Click += new System.EventHandler(this.park13_Click);
            // 
            // park14
            // 
            this.park14.FlatAppearance.BorderSize = 0;
            this.park14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park14.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park14.ForeColor = System.Drawing.Color.White;
            this.park14.Location = new System.Drawing.Point(318, 287);
            this.park14.Name = "park14";
            this.park14.Size = new System.Drawing.Size(47, 77);
            this.park14.TabIndex = 17;
            this.park14.Text = "14";
            this.park14.UseVisualStyleBackColor = true;
            this.park14.Click += new System.EventHandler(this.park14_Click);
            // 
            // park15
            // 
            this.park15.FlatAppearance.BorderSize = 0;
            this.park15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park15.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park15.ForeColor = System.Drawing.Color.White;
            this.park15.Location = new System.Drawing.Point(370, 287);
            this.park15.Name = "park15";
            this.park15.Size = new System.Drawing.Size(47, 77);
            this.park15.TabIndex = 18;
            this.park15.Text = "15";
            this.park15.UseVisualStyleBackColor = true;
            this.park15.Click += new System.EventHandler(this.park15_Click);
            // 
            // park16
            // 
            this.park16.FlatAppearance.BorderSize = 0;
            this.park16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park16.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park16.ForeColor = System.Drawing.Color.White;
            this.park16.Location = new System.Drawing.Point(422, 287);
            this.park16.Name = "park16";
            this.park16.Size = new System.Drawing.Size(47, 77);
            this.park16.TabIndex = 19;
            this.park16.Text = "16";
            this.park16.UseVisualStyleBackColor = true;
            this.park16.Click += new System.EventHandler(this.park16_Click);
            // 
            // park17
            // 
            this.park17.FlatAppearance.BorderSize = 0;
            this.park17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park17.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park17.ForeColor = System.Drawing.Color.White;
            this.park17.Location = new System.Drawing.Point(474, 287);
            this.park17.Name = "park17";
            this.park17.Size = new System.Drawing.Size(47, 77);
            this.park17.TabIndex = 20;
            this.park17.Text = "17";
            this.park17.UseVisualStyleBackColor = true;
            this.park17.Click += new System.EventHandler(this.park17_Click);
            // 
            // park18
            // 
            this.park18.FlatAppearance.BorderSize = 0;
            this.park18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park18.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park18.ForeColor = System.Drawing.Color.White;
            this.park18.Location = new System.Drawing.Point(526, 287);
            this.park18.Name = "park18";
            this.park18.Size = new System.Drawing.Size(47, 77);
            this.park18.TabIndex = 21;
            this.park18.Text = "18";
            this.park18.UseVisualStyleBackColor = true;
            this.park18.Click += new System.EventHandler(this.park18_Click);
            // 
            // park19
            // 
            this.park19.FlatAppearance.BorderSize = 0;
            this.park19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park19.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park19.ForeColor = System.Drawing.Color.White;
            this.park19.Location = new System.Drawing.Point(578, 287);
            this.park19.Name = "park19";
            this.park19.Size = new System.Drawing.Size(47, 77);
            this.park19.TabIndex = 22;
            this.park19.Text = "19";
            this.park19.UseVisualStyleBackColor = true;
            this.park19.Click += new System.EventHandler(this.park19_Click);
            // 
            // park20
            // 
            this.park20.FlatAppearance.BorderSize = 0;
            this.park20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park20.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park20.ForeColor = System.Drawing.Color.White;
            this.park20.Location = new System.Drawing.Point(630, 287);
            this.park20.Name = "park20";
            this.park20.Size = new System.Drawing.Size(47, 77);
            this.park20.TabIndex = 23;
            this.park20.Text = "20";
            this.park20.UseVisualStyleBackColor = true;
            this.park20.Click += new System.EventHandler(this.park20_Click);
            // 
            // park21
            // 
            this.park21.FlatAppearance.BorderSize = 0;
            this.park21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park21.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park21.ForeColor = System.Drawing.Color.White;
            this.park21.Location = new System.Drawing.Point(162, 441);
            this.park21.Name = "park21";
            this.park21.Size = new System.Drawing.Size(47, 77);
            this.park21.TabIndex = 24;
            this.park21.Text = "21";
            this.park21.UseVisualStyleBackColor = true;
            this.park21.Click += new System.EventHandler(this.park21_Click);
            // 
            // park22
            // 
            this.park22.FlatAppearance.BorderSize = 0;
            this.park22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park22.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park22.ForeColor = System.Drawing.Color.White;
            this.park22.Location = new System.Drawing.Point(214, 441);
            this.park22.Name = "park22";
            this.park22.Size = new System.Drawing.Size(47, 77);
            this.park22.TabIndex = 25;
            this.park22.Text = "22";
            this.park22.UseVisualStyleBackColor = true;
            this.park22.Click += new System.EventHandler(this.park22_Click);
            // 
            // park23
            // 
            this.park23.FlatAppearance.BorderSize = 0;
            this.park23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park23.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park23.ForeColor = System.Drawing.Color.White;
            this.park23.Location = new System.Drawing.Point(266, 441);
            this.park23.Name = "park23";
            this.park23.Size = new System.Drawing.Size(47, 77);
            this.park23.TabIndex = 26;
            this.park23.Text = "23";
            this.park23.UseVisualStyleBackColor = true;
            this.park23.Click += new System.EventHandler(this.park23_Click);
            // 
            // park24
            // 
            this.park24.FlatAppearance.BorderSize = 0;
            this.park24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park24.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park24.ForeColor = System.Drawing.Color.White;
            this.park24.Location = new System.Drawing.Point(318, 441);
            this.park24.Name = "park24";
            this.park24.Size = new System.Drawing.Size(47, 77);
            this.park24.TabIndex = 27;
            this.park24.Text = "24";
            this.park24.UseVisualStyleBackColor = true;
            this.park24.Click += new System.EventHandler(this.park24_Click);
            // 
            // park25
            // 
            this.park25.FlatAppearance.BorderSize = 0;
            this.park25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park25.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park25.ForeColor = System.Drawing.Color.White;
            this.park25.Location = new System.Drawing.Point(370, 441);
            this.park25.Name = "park25";
            this.park25.Size = new System.Drawing.Size(47, 77);
            this.park25.TabIndex = 28;
            this.park25.Text = "25";
            this.park25.UseVisualStyleBackColor = true;
            this.park25.Click += new System.EventHandler(this.park25_Click);
            // 
            // park26
            // 
            this.park26.FlatAppearance.BorderSize = 0;
            this.park26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park26.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park26.ForeColor = System.Drawing.Color.White;
            this.park26.Location = new System.Drawing.Point(422, 441);
            this.park26.Name = "park26";
            this.park26.Size = new System.Drawing.Size(47, 77);
            this.park26.TabIndex = 29;
            this.park26.Text = "26";
            this.park26.UseVisualStyleBackColor = true;
            this.park26.Click += new System.EventHandler(this.park26_Click);
            // 
            // park27
            // 
            this.park27.FlatAppearance.BorderSize = 0;
            this.park27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park27.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park27.ForeColor = System.Drawing.Color.White;
            this.park27.Location = new System.Drawing.Point(474, 441);
            this.park27.Name = "park27";
            this.park27.Size = new System.Drawing.Size(47, 77);
            this.park27.TabIndex = 30;
            this.park27.Text = "27";
            this.park27.UseVisualStyleBackColor = true;
            this.park27.Click += new System.EventHandler(this.park27_Click);
            // 
            // park28
            // 
            this.park28.FlatAppearance.BorderSize = 0;
            this.park28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park28.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park28.ForeColor = System.Drawing.Color.White;
            this.park28.Location = new System.Drawing.Point(526, 441);
            this.park28.Name = "park28";
            this.park28.Size = new System.Drawing.Size(47, 77);
            this.park28.TabIndex = 31;
            this.park28.Text = "28";
            this.park28.UseVisualStyleBackColor = true;
            this.park28.Click += new System.EventHandler(this.park28_Click);
            // 
            // park29
            // 
            this.park29.FlatAppearance.BorderSize = 0;
            this.park29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park29.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park29.ForeColor = System.Drawing.Color.White;
            this.park29.Location = new System.Drawing.Point(578, 441);
            this.park29.Name = "park29";
            this.park29.Size = new System.Drawing.Size(47, 77);
            this.park29.TabIndex = 32;
            this.park29.Text = "29";
            this.park29.UseVisualStyleBackColor = true;
            this.park29.Click += new System.EventHandler(this.park29_Click);
            // 
            // park30
            // 
            this.park30.FlatAppearance.BorderSize = 0;
            this.park30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park30.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park30.ForeColor = System.Drawing.Color.White;
            this.park30.Location = new System.Drawing.Point(630, 441);
            this.park30.Name = "park30";
            this.park30.Size = new System.Drawing.Size(47, 77);
            this.park30.TabIndex = 33;
            this.park30.Text = "30";
            this.park30.UseVisualStyleBackColor = true;
            this.park30.Click += new System.EventHandler(this.park30_Click);
            // 
            // park1
            // 
            this.park1.FlatAppearance.BorderSize = 0;
            this.park1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.park1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.park1.ForeColor = System.Drawing.Color.White;
            this.park1.Location = new System.Drawing.Point(162, 124);
            this.park1.Name = "park1";
            this.park1.Size = new System.Drawing.Size(47, 77);
            this.park1.TabIndex = 4;
            this.park1.Text = "01";
            this.park1.UseVisualStyleBackColor = true;
            this.park1.Click += new System.EventHandler(this.park1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project.Properties.Resources.주차장;
            this.pictureBox1.Location = new System.Drawing.Point(48, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(811, 508);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::Project.Properties.Resources.closeimg1;
            this.button1.Location = new System.Drawing.Point(918, 607);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 669);
            this.Controls.Add(this.park30);
            this.Controls.Add(this.park29);
            this.Controls.Add(this.park28);
            this.Controls.Add(this.park27);
            this.Controls.Add(this.park26);
            this.Controls.Add(this.park25);
            this.Controls.Add(this.park24);
            this.Controls.Add(this.park23);
            this.Controls.Add(this.park22);
            this.Controls.Add(this.park21);
            this.Controls.Add(this.park20);
            this.Controls.Add(this.park19);
            this.Controls.Add(this.park18);
            this.Controls.Add(this.park17);
            this.Controls.Add(this.park16);
            this.Controls.Add(this.park15);
            this.Controls.Add(this.park14);
            this.Controls.Add(this.park13);
            this.Controls.Add(this.park12);
            this.Controls.Add(this.park11);
            this.Controls.Add(this.park10);
            this.Controls.Add(this.park9);
            this.Controls.Add(this.park8);
            this.Controls.Add(this.park7);
            this.Controls.Add(this.park6);
            this.Controls.Add(this.park5);
            this.Controls.Add(this.park4);
            this.Controls.Add(this.park3);
            this.Controls.Add(this.park2);
            this.Controls.Add(this.park1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form2_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button park1;
        private System.Windows.Forms.Button park2;
        private System.Windows.Forms.Button park3;
        private System.Windows.Forms.Button park4;
        private System.Windows.Forms.Button park5;
        private System.Windows.Forms.Button park6;
        private System.Windows.Forms.Button park7;
        private System.Windows.Forms.Button park8;
        private System.Windows.Forms.Button park9;
        private System.Windows.Forms.Button park10;
        private System.Windows.Forms.Button park11;
        private System.Windows.Forms.Button park12;
        private System.Windows.Forms.Button park13;
        private System.Windows.Forms.Button park14;
        private System.Windows.Forms.Button park15;
        private System.Windows.Forms.Button park16;
        private System.Windows.Forms.Button park17;
        private System.Windows.Forms.Button park18;
        private System.Windows.Forms.Button park19;
        private System.Windows.Forms.Button park20;
        private System.Windows.Forms.Button park21;
        private System.Windows.Forms.Button park22;
        private System.Windows.Forms.Button park23;
        private System.Windows.Forms.Button park24;
        private System.Windows.Forms.Button park25;
        private System.Windows.Forms.Button park26;
        private System.Windows.Forms.Button park27;
        private System.Windows.Forms.Button park28;
        private System.Windows.Forms.Button park29;
        private System.Windows.Forms.Button park30;
    }
}