﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public class ParkingCar
    {
        public int ParkNum { get; set; }
        public string CarNumber { get; set; }
        public string DriverName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime ParkingTime { get; set; }
    }
}
