num = int(input('숫자입력'))
print("num = ",num)